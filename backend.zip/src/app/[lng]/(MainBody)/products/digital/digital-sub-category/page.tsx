"use client";
import SubCategoryDigital from "@/Components/Products/Digital/SubCategoryDigital";

const SubCategoryDigitalContainer = () => {
  return <SubCategoryDigital />;
};

export default SubCategoryDigitalContainer;
