"use client";
import AddProduct from "@/Components/Products/Physical/AddProduct";

const AddProductContainer = () => {
  return <AddProduct />;
};

export default AddProductContainer;
