'use client'
import CreateUser from "@/Components/Users/CreateUser";
import React from "react";

const CreateUserContainer = () => {
  return <CreateUser />;
};

export default CreateUserContainer;
