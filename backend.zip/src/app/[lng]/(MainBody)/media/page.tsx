'use client'
import Media from "@/Components/Media";

const MediaContainer = () => {
  return <Media />;
};

export default MediaContainer;
