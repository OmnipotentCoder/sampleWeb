"use client";
import Translations from "@/Components/Localization/Translations";

const TranslationContainer = () => (
  <Translations />
)

export default TranslationContainer;
