'use client'
import ListPages from "@/Components/Pages/PageList";

const PageListContainer = () => {
  return <ListPages />;
};

export default PageListContainer;
