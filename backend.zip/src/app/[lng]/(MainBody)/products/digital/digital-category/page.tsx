"use client";
import CategoryDigital from "@/Components/Products/Digital/CategoryDigital";

const DigitalCategoryContainer = () => {
  return <CategoryDigital />;
};

export default DigitalCategoryContainer;
