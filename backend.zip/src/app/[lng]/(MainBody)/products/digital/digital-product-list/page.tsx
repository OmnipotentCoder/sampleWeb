"use client";
import ProductListDigital from "@/Components/Products/Digital/ProductListDigital";

const ProductListDigitalContainer = () => {
  return <ProductListDigital />;
};

export default ProductListDigitalContainer;
