"use client";
import Taxes from "@/Components/Localization/Taxes";

const TaxesContainer = () => {
  return <Taxes />;
};

export default TaxesContainer;
