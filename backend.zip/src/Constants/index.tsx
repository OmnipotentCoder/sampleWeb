export const Href = '#javascript'
export const ImagePath = "/assets/images";