'use client'
import DashboardContainer from "@/Components/Dashboard";

const Dashboard = () => {
  return <DashboardContainer />;
};

export default Dashboard;
