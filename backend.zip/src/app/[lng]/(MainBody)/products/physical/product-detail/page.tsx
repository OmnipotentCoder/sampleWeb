'use client'
import ProductDetail from "@/Components/Products/Physical/ProductDetail";

const ProductDetailContainer = () => {
  return <ProductDetail />;
};

export default ProductDetailContainer;
