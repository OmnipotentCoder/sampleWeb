export interface CommonBreadcrumbType {
    title: string;
    parent: string;
  }