export default function Home() {
  return <h1>Multikart</h1>;
}
