"use client";
import AddDigitalProduct from "@/Components/Products/Digital/AddDigitalProduct";

const AddDigitalProductContainer = () => {
  return <AddDigitalProduct />;
};

export default AddDigitalProductContainer;
