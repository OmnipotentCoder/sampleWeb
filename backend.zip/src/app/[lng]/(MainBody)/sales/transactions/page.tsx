"use client";
import SalesTransaction from "@/Components/Sales/SalesTransaction";

const SalesTransactionContainer = () => {
  return <SalesTransaction />;
};

export default SalesTransactionContainer;
