'use client'
import DummyLogin from "@/Components/DummyLogin";

const LoginPage = () => {
  return <DummyLogin />;
};

export default LoginPage;
