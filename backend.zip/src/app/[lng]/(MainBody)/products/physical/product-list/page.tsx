"use client";
import ProductList from "@/Components/Products/Physical/ProductList";

const ProductListContainer = () => {
  return <ProductList />;
};

export default ProductListContainer;
