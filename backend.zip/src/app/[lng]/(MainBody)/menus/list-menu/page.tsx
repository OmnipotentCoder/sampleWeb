"use client";
import MenuList from "@/Components/Menu/MenuList";

const ListMenuContainer = () => {
  return <MenuList />;
};

export default ListMenuContainer;
