"use client";
import CreateCoupons from "@/Components/Coupons/CreateCoupons";

const CreateCouponsContainer = () => {
  return <CreateCoupons />;
};

export default CreateCouponsContainer;
