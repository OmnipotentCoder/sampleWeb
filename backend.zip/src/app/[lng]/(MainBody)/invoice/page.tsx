"use client";
import Invoice from "@/Components/Invoice";

const InvoiceContainer = () => {
  return <Invoice />;
};

export default InvoiceContainer;
