'use client'
import Reports from "@/Components/Reports";

const ReportsContainer = () => {
  return <Reports />;
};

export default ReportsContainer;
