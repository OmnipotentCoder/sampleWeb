"use client";
import Profile from "@/Components/Settings";
import React from "react";

const ProfileSettings = () => {
  return <Profile />;
};

export default ProfileSettings;
