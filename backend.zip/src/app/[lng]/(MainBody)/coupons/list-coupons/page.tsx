"use client";

import ListCoupons from "@/Components/Coupons/CouponList";

const ListCouponsContainer = () => {
  return <ListCoupons />;
};

export default ListCouponsContainer;
