'use client'
import Category from "@/Components/Products/Physical/Category";
import React from "react";

const ProductCategory = () => {
  return <Category />;
};

export default ProductCategory;
