"use client";
import SalesOrders from "@/Components/Sales/SaleOrders";

const SaleOrdersContainer = () => {
  return <SalesOrders />;
};

export default SaleOrdersContainer;
