const loadCurrency = [
  {
    currency: 'USD',
    name:'doller',
    symbol: '$',
    value: 1
  },
  {
    currency: 'IND',
    name:'rupees',
    symbol: '₹',
    value: 60.0
  },
  {
    currency: 'EUR',
    name:'euro',
    symbol: '€',
    value: 52.00
  },
  {
    currency: 'GBP',
    name:'pound',
    symbol: '£',
    value: 62.00
  }
]

module.exports = loadCurrency;
