"use client";
import UserList from "@/Components/Users/UsersList";

const ListUserContainer = () => {
  return <UserList />;
};

export default ListUserContainer;
