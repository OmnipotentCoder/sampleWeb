"use client";
import CurrencyRates from "@/Components/Localization/CurrencyRates";

const CurrencyRatesContainer = () => {
  return <CurrencyRates />;
};

export default CurrencyRatesContainer;
