'use client'
import SubCategory from "@/Components/Products/Physical/SubCategory";

const ProductSubCategory = () => {
  return <SubCategory />;
};

export default ProductSubCategory;
