'use client'
import Login from "@/Layout/Login";

const LoginContainer = () => {
  return <Login />;
};

export default LoginContainer;
