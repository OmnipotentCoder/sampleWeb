"use client"
import CreateMenu from "@/Components/Menu/CreateMenu";

const CreateMenuContainer = () => {
  return <CreateMenu />;
};

export default CreateMenuContainer;
