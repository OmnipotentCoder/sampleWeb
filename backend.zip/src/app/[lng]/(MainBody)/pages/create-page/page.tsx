"use client";
import CreatePage from "@/Components/Pages/CreatePage";

const CreatePageContainer = () => {
  return <CreatePage />;
};

export default CreatePageContainer;
